package com.example.xinychan.aidlclient;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.xinychan.aidlservice.IEasyService;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final String ACTION = "com.example.xinychan.aidlservice.EasyService";
    private static final String PACK_NAME = "com.example.xinychan.aidlservice";

    private boolean isConnection = false;

    private IEasyService mEasyService;

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.i(TAG, "ServiceConnection onServiceConnected");
            mEasyService = IEasyService.Stub.asInterface(service);
            if (mEasyService == null) {
                Log.e(TAG, "ServiceConnection mEasyService null error");
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.i(TAG, "ServiceConnection onServiceDisconnected");
            mEasyService = null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onDestroy() {
        if (isConnection) {
            unbindService(mConnection);
            isConnection = false;
        }
        super.onDestroy();
    }

    public void clickInit(View view) {
        if (isConnection) {
            Log.i(TAG, "already clickInit");
            return;
        }
        Intent intent = new Intent();
        intent.setAction(ACTION);
        // 注意在 Android 5.0以后，不能通过隐式 Intent 启动 service，必须指定包名
        intent.setPackage(PACK_NAME);
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
        isConnection = true;
    }

    public void clickConnect(View view) {
        if (mEasyService != null) {
            try {
                mEasyService.connect("clickConnect");
            } catch (RemoteException e) {
                Log.e(TAG, "clickConnect RemoteException");
            }
        } else {
            Log.e(TAG, "clickConnect mEasyService null");
        }
    }

    public void clickDisConnect(View view) {
        if (mEasyService != null) {
            try {
                mEasyService.disConnect("clickDisConnect");
            } catch (RemoteException e) {
                Log.e(TAG, "clickDisConnect RemoteException");
            }
        } else {
            Log.e(TAG, "clickDisConnect mEasyService null");
        }
    }

    public void clickGetInfo(View view) {
        if (mEasyService != null) {
            try {
                String info = mEasyService.getInfo();
                Log.i(TAG, "clickGetInfo:" + info);
                Toast.makeText(this, info, Toast.LENGTH_SHORT).show();
            } catch (RemoteException e) {
                Log.e(TAG, "clickGetInfo RemoteException");
            }
        } else {
            Log.e(TAG, "clickGetInfo mEasyService null");
        }
    }
}
